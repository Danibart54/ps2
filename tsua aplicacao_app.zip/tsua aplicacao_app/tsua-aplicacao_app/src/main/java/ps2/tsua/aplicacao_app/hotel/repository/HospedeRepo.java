package ps2.tsua.aplicacao_app.hotel.repository;

import com.hotel.model.Hospede;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HospedeDAO extends JpaRepository<Hospede, Long> {
    // aqui você pode criar queries personalizadas, ex:
    Hospede findByNome(String nome);
}
