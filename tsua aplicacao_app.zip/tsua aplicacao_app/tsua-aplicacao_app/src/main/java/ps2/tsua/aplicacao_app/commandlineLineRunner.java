package ps2.tsua.aplicacao_app;

public interface commandlineLineRunner {

}
