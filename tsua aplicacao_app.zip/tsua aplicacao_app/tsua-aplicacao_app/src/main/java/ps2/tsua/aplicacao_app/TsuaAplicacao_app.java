package ps2.tsua.aplicacao_app;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import ps2.tsua.aplicacao_app.hotel.repository.HospedeRepo;
import ps2.tsua.aplicacao_app.model.Hospede;

import java.util.Scanner;

@SpringBootApplication
public class TsuaAplicacao_app implements CommandLineRunner {

    private HospedeRepo hospedeRepo;

    public void MainApp(HospedeRepo hospedeRepo) {
        this.hospedeRepo = hospedeRepo;
    }

    public static void main(String[] args) {
        SpringApplication.run(TsuaAplicacao_app.class, args);
    }

    @Override
    public void run(String... args) {
        Scanner sc = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\n===== Sistema de Hóspedes =====");
            System.out.println("(1) Listar todos");
            System.out.println("(2) Buscar por ID");
            System.out.println("(3) Criar um novo");
            System.out.println("(4) Alterar os dados");
            System.out.println("(5) Apagar por ID");
            System.out.println("(0) Sair");
            System.out.print("Escolha: ");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1 -> hospedeRepo.findAll().forEach(System.out::println);
                case 2 -> {
                    System.out.print("Digite o ID: ");
                    Long id = sc.nextLong();
                    sc.nextLine();
                    hospedeRepo.findById(id)
                            .ifPresentOrElse(
                                    System.out::println,
                                    () -> System.out.println("⚠️ Hóspede não encontrado.")
                            );
                }
                case 3 -> {
                    System.out.print("Nome: ");
                    String nome = sc.nextLine();
                    System.out.print("Telefone: ");
                    String telefone = sc.nextLine();
                    Hospede h = new Hospede(null, nome, telefone);
                    hospedeRepo.save(h);
                    System.out.println("✅ Hóspede cadastrado!");
                }
                case 4 -> {
                    System.out.print("ID do hóspede: ");
                    Long id = sc.nextLong();
                    sc.nextLine();
                    hospedeRepo.findById(id).ifPresentOrElse(h -> {
                        System.out.print("Novo nome: ");
                        h.setNome(sc.nextLine());
                        System.out.print("Novo telefone: ");
                        h.setTelefone(sc.nextLine());
                        hospedeRepo.save(h);
                        System.out.println("✅ Atualizado!");
                    }, () -> System.out.println("⚠️ Hóspede não encontrado."));
                }
                case 5 -> {
                    System.out.print("ID do hóspede: ");
                    Long id = sc.nextLong();
                    sc.nextLine();
                    if (hospedeRepo.existsById(id)) {
                        hospedeRepo.deleteById(id);
                        System.out.println("✅ Excluído!");
                    } else {
                        System.out.println("⚠️ Hóspede não encontrado.");
                    }
                }
                case 0 -> System.out.println("Encerrando...");
                default -> System.out.println("⚠️ Opção inválida!");
            }

        } while (opcao != 0);

        sc.close();
    }
}
